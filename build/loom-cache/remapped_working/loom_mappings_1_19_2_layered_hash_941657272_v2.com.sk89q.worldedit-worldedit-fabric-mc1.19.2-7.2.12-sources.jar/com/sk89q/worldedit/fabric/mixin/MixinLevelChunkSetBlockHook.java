/*
 * WorldEdit, a Minecraft world manipulation toolkit
 * Copyright (C) sk89q <http://www.sk89q.com>
 * Copyright (C) WorldEdit team and contributors
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <https://www.gnu.org/licenses/>.
 */

package com.sk89q.worldedit.fabric.mixin;

import com.sk89q.worldedit.fabric.internal.ExtendedChunk;
import net.minecraft.block.BlockState;
import net.minecraft.server.MinecraftServer;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import net.minecraft.util.registry.Registry;
import net.minecraft.world.HeightLimitView;
import net.minecraft.world.World;
import net.minecraft.world.biome.Biome;
import net.minecraft.world.chunk.Chunk;
import net.minecraft.world.chunk.ChunkSection;
import net.minecraft.world.chunk.UpgradeData;
import net.minecraft.world.chunk.WorldChunk;
import net.minecraft.world.gen.chunk.BlendingData;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.Slice;

import javax.annotation.Nullable;

@Mixin(WorldChunk.class)
public abstract class MixinLevelChunkSetBlockHook extends Chunk implements ExtendedChunk {
    private boolean shouldUpdate = true;

    public MixinLevelChunkSetBlockHook(ChunkPos chunkPos, UpgradeData upgradeData, HeightLimitView levelHeightAccessor, Registry<Biome> registry, long l, @org.jetbrains.annotations.Nullable ChunkSection[] levelChunkSections, @org.jetbrains.annotations.Nullable BlendingData blendingData) {
        super(chunkPos, upgradeData, levelHeightAccessor, registry, l, levelChunkSections, blendingData);
    }

    @Nullable
    @Override
    public BlockState setBlockState(BlockPos pos, BlockState state, boolean moved, boolean update) {
        // save the state for the hook
        shouldUpdate = update;
        try {
            return setBlockState(pos, state, moved);
        } finally {
            // restore natural mode
            shouldUpdate = true;
        }
    }

    @Redirect(
        method = "setBlockState",
        slice = @Slice(
            from = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;is(Lnet/minecraft/world/level/block/Block;)Z")
        ),
        at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;onPlace(Lnet/minecraft/world/level/Level;Lnet/minecraft/core/BlockPos;Lnet/minecraft/world/level/block/state/BlockState;Z)V")
    )
    public void setBlockStateHook(BlockState target, World world, BlockPos pos, BlockState old, boolean move) {
        boolean localShouldUpdate;
        MinecraftServer server = world.getServer();
        if (server == null || Thread.currentThread() != server.getThread()) {
            // We're not on the server thread for some reason, WorldEdit will never be here
            // so we'll just ignore our flag
            localShouldUpdate = true;
        } else {
            localShouldUpdate = shouldUpdate;
        }
        if (localShouldUpdate) {
            target.onBlockAdded(world, pos, old, move);
        }
    }
}
