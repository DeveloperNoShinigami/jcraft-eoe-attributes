package software.bernie.geckolib3.renderers.geo;

import javax.annotation.Nonnull;
import net.minecraft.block.BlockState;
import net.minecraft.block.FacingBlock;
import net.minecraft.block.HorizontalFacingBlock;
import net.minecraft.block.entity.BlockEntity;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.render.OverlayTexture;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.VertexConsumer;
import net.minecraft.client.render.VertexConsumerProvider;
import net.minecraft.client.render.block.entity.BlockEntityRenderer;
import net.minecraft.client.util.math.MatrixStack;
import net.minecraft.util.Identifier;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Direction;
import net.minecraft.util.math.Matrix4f;
import net.minecraft.util.math.Vec3d;
import net.minecraft.util.math.Vec3f;
import org.jetbrains.annotations.ApiStatus.AvailableSince;

import com.mojang.blaze3d.systems.RenderSystem;
import software.bernie.geckolib3.core.IAnimatable;
import software.bernie.geckolib3.core.IAnimatableModel;
import software.bernie.geckolib3.core.controller.AnimationController;
import software.bernie.geckolib3.core.util.Color;
import software.bernie.geckolib3.geo.render.built.GeoBone;
import software.bernie.geckolib3.geo.render.built.GeoModel;
import software.bernie.geckolib3.model.AnimatedGeoModel;
import software.bernie.geckolib3.util.EModelRenderCycle;
import software.bernie.geckolib3.util.IRenderCycle;
import software.bernie.geckolib3.util.RenderUtils;

public abstract class GeoBlockRenderer<T extends BlockEntity & IAnimatable>
		implements IGeoRenderer<T>, BlockEntityRenderer {
	static {
		AnimationController.addModelFetcher((IAnimatable object) -> {
			if (object instanceof BlockEntity tile) {
				BlockEntityRenderer<BlockEntity> renderer = MinecraftClient.getInstance().getBlockEntityRenderDispatcher()
						.get(tile);

				if (renderer instanceof GeoBlockRenderer blockRenderer)
					return (IAnimatableModel<Object>)blockRenderer.getGeoModelProvider();
			}
			return null;
		});
	}

	protected final AnimatedGeoModel<T> modelProvider;
	protected float widthScale = 1;
	protected float heightScale = 1;
	protected Matrix4f dispatchedMat = new Matrix4f();
	protected Matrix4f renderEarlyMat = new Matrix4f();
	protected T animatable;
	protected VertexConsumerProvider rtb = null;

	private IRenderCycle currentModelRenderCycle = EModelRenderCycle.INITIAL;

	public GeoBlockRenderer(AnimatedGeoModel<T> modelProvider) {
		this.modelProvider = modelProvider;
	}

	@Override
	public void renderEarly(T animatable, MatrixStack poseStack, float partialTick, VertexConsumerProvider bufferSource,
							VertexConsumer buffer, int packedLight, int packedOverlay, float red, float green, float blue,
							float alpha) {
		this.renderEarlyMat = poseStack.peek().getPositionMatrix().copy();
		this.animatable = animatable;

		IGeoRenderer.super.renderEarly(animatable, poseStack, partialTick, bufferSource, buffer, packedLight, packedOverlay, red, green, blue, alpha);
	}

	@Override
	public void render(BlockEntity tile, float partialTicks, MatrixStack poseStack, VertexConsumerProvider bufferSource,
			int packedLight, int packedOverlay) {
		render((T)tile, partialTicks, poseStack, bufferSource, packedLight);
	}

	public void render(T tile, float partialTick, MatrixStack poseStack, VertexConsumerProvider bufferSource, int packedLight) {
		GeoModel model = modelProvider.getModel(modelProvider.getModelResource(tile));
		modelProvider.setLivingAnimations(tile, getInstanceId(tile)); // TODO change to setCustomAnimations in 1.20+
		this.dispatchedMat = poseStack.peek().getPositionMatrix().copy();
		this.setCurrentModelRenderCycle(EModelRenderCycle.INITIAL);
		poseStack.push();
		poseStack.translate(0, 0.01f, 0);
		poseStack.translate(0.5, 0, 0.5);

		rotateBlock(getFacing(tile), poseStack);

		RenderSystem.setShaderTexture(0, getTextureLocation(tile));
		Color renderColor = getRenderColor(tile, partialTick, poseStack, bufferSource, null, packedLight);
		RenderLayer renderType = getRenderType(tile, partialTick, poseStack, bufferSource, null, packedLight,
				getTextureLocation(tile));
		render(model, tile, partialTick, renderType, poseStack, bufferSource, null, packedLight, OverlayTexture.DEFAULT_UV,
				renderColor.getRed() / 255f, renderColor.getGreen() / 255f,
				renderColor.getBlue() / 255f, renderColor.getAlpha() / 255f);
		poseStack.pop();
	}

	@Override
	public void renderRecursively(GeoBone bone, MatrixStack poseStack, VertexConsumer buffer, int packedLight,
								  int packedOverlay, float red, float green, float blue, float alpha) {
		if (bone.isTrackingXform()) {
			Matrix4f poseState = poseStack.peek().getPositionMatrix().copy();
			Matrix4f localMatrix = RenderUtils.invertAndMultiplyMatrices(poseState, this.dispatchedMat);
			BlockPos pos = this.animatable.getPos();

			bone.setModelSpaceXform(RenderUtils.invertAndMultiplyMatrices(poseState, this.renderEarlyMat));
			localMatrix.addToLastColumn(new Vec3f(getRenderOffset(this.animatable, 1)));
			bone.setLocalSpaceXform(localMatrix);

			Matrix4f worldState = localMatrix.copy();

			worldState.addToLastColumn(new Vec3f(pos.getX(), pos.getY(), pos.getZ()));
			bone.setWorldSpaceXform(worldState);
		}

		IGeoRenderer.super.renderRecursively(bone, poseStack, buffer, packedLight, packedOverlay, red, green, blue,
				alpha);
	}

	public Vec3d getRenderOffset(T animatable, float partialTick) {
		return Vec3d.ZERO;
	}

	/**
	 * Use {@link IGeoRenderer#getInstanceId(Object)}<br>
	 * Remove in 1.20+
	 */
	@Deprecated(forRemoval = true)
	public Integer getUniqueID(T animatable) {
		return getInstanceId(animatable);
	}

	@Override
	public int getInstanceId(T animatable) {
		return animatable.getPos().hashCode();
	}

	@Override
	public AnimatedGeoModel<T> getGeoModelProvider() {
		return this.modelProvider;
	}

	@AvailableSince(value = "3.1.24")
	@Override
	@Nonnull
	public IRenderCycle getCurrentModelRenderCycle() {
		return this.currentModelRenderCycle;
	}

	@AvailableSince(value = "3.1.24")
	@Override
	public void setCurrentModelRenderCycle(IRenderCycle currentModelRenderCycle) {
		this.currentModelRenderCycle = currentModelRenderCycle;
	}

	@AvailableSince(value = "3.1.24")
	@Override
	public float getWidthScale(T animatable) {
		return this.widthScale;
	}

	@AvailableSince(value = "3.1.24")
	@Override
	public float getHeightScale(T entity) {
		return this.heightScale;
	}

	protected void rotateBlock(Direction facing, MatrixStack poseStack) {
		switch (facing) {
			case SOUTH -> poseStack.multiply(Vec3f.POSITIVE_Y.getDegreesQuaternion(180));
			case WEST -> poseStack.multiply(Vec3f.POSITIVE_Y.getDegreesQuaternion(90));
			case NORTH -> poseStack.multiply(Vec3f.POSITIVE_Y.getDegreesQuaternion(0));
			case EAST -> poseStack.multiply(Vec3f.POSITIVE_Y.getDegreesQuaternion(270));
			case UP -> poseStack.multiply(Vec3f.POSITIVE_X.getDegreesQuaternion(90));
			case DOWN -> poseStack.multiply(Vec3f.NEGATIVE_X.getDegreesQuaternion(90));
		}
	}

	private Direction getFacing(T tile) {
		BlockState blockState = tile.getCachedState();
		if (blockState.contains(HorizontalFacingBlock.FACING)) {
			return blockState.get(HorizontalFacingBlock.FACING);
		}
		else if (blockState.contains(FacingBlock.FACING)) {
			return blockState.get(FacingBlock.FACING);
		}
		else {
			return Direction.NORTH;
		}
	}

	@Override
	public Identifier getTextureLocation(T animatable) {
		return this.modelProvider.getTextureResource(animatable);
	}
	
	@Override
	public Identifier getTextureResource(T animatable) {
		return this.modelProvider.getTextureResource(animatable);
	}

	@Override
	public void setCurrentRTB(VertexConsumerProvider bufferSource) {
		this.rtb = bufferSource;
	}

	@Override
	public VertexConsumerProvider getCurrentRTB() {
		return this.rtb;
	}
}
