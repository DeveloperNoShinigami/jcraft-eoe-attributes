package software.bernie.example.client.model.entity;

import net.minecraft.util.Identifier;
import software.bernie.example.client.EntityResources;
import software.bernie.example.entity.BikeEntity;
import software.bernie.geckolib3.model.AnimatedGeoModel;

public class BikeModel extends AnimatedGeoModel<BikeEntity> {
	@Override
	public Identifier getAnimationResource(BikeEntity entity) {
		return EntityResources.BIKE_ANIMATIONS;
	}

	@Override
	public Identifier getModelResource(BikeEntity entity) {
		return EntityResources.BIKE_MODEL;
	}

	@Override
	public Identifier getTextureResource(BikeEntity entity) {
		return EntityResources.BIKE_TEXTURE;
	}
}