package software.bernie.example.client.model.armor;

import net.minecraft.util.Identifier;
import software.bernie.example.client.EntityResources;
import software.bernie.example.item.GeckoArmorItem;
import software.bernie.geckolib3.model.AnimatedGeoModel;

public class GeckoArmorModel extends AnimatedGeoModel<GeckoArmorItem> {
	@Override
	public Identifier getModelResource(GeckoArmorItem object) {
		return EntityResources.GECKOARMOR_MODEL;
	}

	@Override
	public Identifier getTextureResource(GeckoArmorItem object) {
		return EntityResources.GECKOARMOR_TEXTURE;
	}

	@Override
	public Identifier getAnimationResource(GeckoArmorItem animatable) {
		return EntityResources.GECKOARMOR_ANIMATIONS;
	}
}
