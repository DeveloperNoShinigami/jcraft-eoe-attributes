package software.bernie.example.client.model.entity;

import net.minecraft.util.Identifier;
import software.bernie.example.client.EntityResources;
import software.bernie.example.entity.LEEntity;
import software.bernie.geckolib3.model.AnimatedTickingGeoModel;

public class LEModel extends AnimatedTickingGeoModel<LEEntity> {

	@Override
	public Identifier getModelResource(LEEntity object) {
		return EntityResources.LAYER_EXAMPLE_MODEL;
	}

	@Override
	public Identifier getTextureResource(LEEntity object) {
		return EntityResources.LAYER_EXAMPLE_TEXTURE;
	}

	@Override
	public Identifier getAnimationResource(LEEntity animatable) {
		return EntityResources.LAYER_EXAMPLE_ANIMATIONS;
	}

}