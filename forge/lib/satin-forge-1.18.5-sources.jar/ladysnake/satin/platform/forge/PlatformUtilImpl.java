package ladysnake.satin.platform.forge;

import com.mojang.blaze3d.vertex.VertexFormat;
import java.io.IOException;
import net.minecraft.client.renderer.ShaderInstance;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.ResourceProvider;

public class PlatformUtilImpl {

    public static ShaderInstance getShaderProgramClass(ResourceProvider resourceManager, ResourceLocation location, VertexFormat vertexFormat) throws IOException {
        return new ShaderInstance(resourceManager, location, vertexFormat);
    }
}
