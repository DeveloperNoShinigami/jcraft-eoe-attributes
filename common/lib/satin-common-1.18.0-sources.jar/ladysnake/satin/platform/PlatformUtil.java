package ladysnake.satin.platform;

import dev.architectury.injectables.annotations.ExpectPlatform;
import java.io.IOException;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_5912;
import net.minecraft.class_5944;

public class PlatformUtil {

    @ExpectPlatform
    public static class_5944 getShaderProgramClass(class_5912 resourceManager, class_2960 location, class_293 vertexFormat) throws IOException {
        throw new AssertionError();
    }
}
