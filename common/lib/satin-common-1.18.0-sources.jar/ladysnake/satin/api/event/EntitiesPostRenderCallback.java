/*
 * Satin
 * Copyright (C) 2019-2024 Ladysnake
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; If not, see <https://www.gnu.org/licenses>.
 */
package ladysnake.satin.api.event;

import dev.architectury.event.Event;
import dev.architectury.event.EventFactory;
import net.minecraft.class_4184;
import net.minecraft.class_4604;

@FunctionalInterface
public interface EntitiesPostRenderCallback {
    /**
     * Fired after Minecraft has rendered all entities and before it renders block entities.
     */
    Event<EntitiesPostRenderCallback> EVENT = EventFactory.createLoop();

    void onEntitiesRendered(class_4184 camera, class_4604 frustum, float tickDelta);
}
