/*
 * Satin
 * Copyright (C) 2019-2024 Ladysnake
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; If not, see <https://www.gnu.org/licenses>.
 */
package ladysnake.satin.impl;

import org.jetbrains.annotations.Nullable;

import java.util.function.Consumer;
import net.minecraft.class_1921;
import net.minecraft.class_293;

public final class RenderLayerDuplicator {

    public static class_1921 copy(class_1921 existing, String newName,  Consumer<class_1921.class_4688.class_4689> op) {
        return copy(existing, newName, null, op);
    }

    /**
     *
     * @param existing the {@link class_1921} to copy
     * @param newName a unique name for the new {@link class_1921}
     * @param vertexFormat the new vertex format, or {@code null} if {@code existing}'s format should be used
     * @param op the transformation to apply to {@code existing}'s parameters
     * @return a new {@link class_1921} based on {@code existing}
     */
    public static class_1921 copy(class_1921 existing, String newName, @Nullable class_293 vertexFormat, Consumer<class_1921.class_4688.class_4689> op) {
        checkDefaultImpl(existing);
        return ((SatinRenderLayer) existing).satin$copy(newName, vertexFormat, op);
    }

    public static class_1921.class_4688 copyPhaseParameters(class_1921 existing, Consumer<class_1921.class_4688.class_4689> op) {
        checkDefaultImpl(existing);
        return ((SatinRenderLayer) existing).satin$copyPhaseParameters(op);
    }

    private static void checkDefaultImpl(class_1921 existing) {
        if (!(existing instanceof SatinRenderLayer)) {
            throw new IllegalArgumentException("Unrecognized RenderLayer implementation " + existing.getClass() + ". Layer duplication is only applicable to the default (MultiPhase) implementation");
        }
    }

    public interface SatinRenderLayer {
        class_1921 satin$copy(String newName, @Nullable class_293 vertexFormat, Consumer<class_1921.class_4688.class_4689> op);
        class_1921.class_4688 satin$copyPhaseParameters(Consumer<class_1921.class_4688.class_4689> op);
    }
}
