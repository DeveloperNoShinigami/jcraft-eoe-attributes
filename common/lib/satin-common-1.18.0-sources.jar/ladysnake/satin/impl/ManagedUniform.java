/*
 * Satin
 * Copyright (C) 2019-2024 Ladysnake
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; If not, see <https://www.gnu.org/licenses>.
 */
package ladysnake.satin.impl;

import ladysnake.satin.api.managed.uniform.Uniform1f;
import ladysnake.satin.api.managed.uniform.Uniform1i;
import ladysnake.satin.api.managed.uniform.Uniform2f;
import ladysnake.satin.api.managed.uniform.Uniform2i;
import ladysnake.satin.api.managed.uniform.Uniform3f;
import ladysnake.satin.api.managed.uniform.Uniform3i;
import ladysnake.satin.api.managed.uniform.Uniform4f;
import ladysnake.satin.api.managed.uniform.Uniform4i;
import ladysnake.satin.api.managed.uniform.UniformMat4;
import net.minecraft.class_283;
import net.minecraft.class_284;
import net.minecraft.class_5944;
import org.joml.Matrix4f;
import org.joml.Vector2f;
import org.joml.Vector3f;
import org.joml.Vector4f;

import java.util.ArrayList;
import java.util.List;

public final class ManagedUniform extends ManagedUniformBase implements
        Uniform1i, Uniform2i, Uniform3i, Uniform4i,
        Uniform1f, Uniform2f, Uniform3f, Uniform4f,
        UniformMat4 {

    private static final class_284[] NO_TARGETS = new class_284[0];

    private final int count;

    private class_284[] targets = NO_TARGETS;
    private int i0, i1, i2, i3;
    private float f0, f1, f2, f3;
    private boolean firstUpload = true;

    public ManagedUniform(String name, int count) {
        super(name);
        this.count = count;
    }

    @Override
    public boolean findUniformTargets(List<class_283> shaders) {
        List<class_284> list = new ArrayList<>();
        for (class_283 shader : shaders) {
            class_284 uniform = shader.method_1295().method_1271(this.name);

            if (uniform != null) {
                if (uniform.method_35661() != this.count) {
                    throw new IllegalStateException("Mismatched number of values, expected " + this.count + " but JSON definition declares " + uniform.method_35661());
                }
                list.add(uniform);
            }
        }

        if (list.size() > 0) {
            this.targets = list.toArray(new class_284[0]);
            this.syncCurrentValues();
            return true;
        } else {
            this.targets = NO_TARGETS;
            return false;
        }
    }

    @Override
    public boolean findUniformTarget(class_5944 shader) {
        class_284 uniform = shader.method_34582(this.name);
        if (uniform != null) {
            this.targets = new class_284[] {uniform};
            this.syncCurrentValues();
            return true;
        } else {
            this.targets = NO_TARGETS;
            return false;
        }
    }

    private void syncCurrentValues() {
        if (!this.firstUpload) {
            for (class_284 target : this.targets) {
                if (target.method_35663() != null) {
                    target.method_1248(i0, i1, i2, i3);
                } else {
                    assert target.method_35664() != null;
                    target.method_1252(f0, f1, f2, f3);
                }
            }
        }
    }

    @Override
    public void set(int value) {
        class_284[] targets = this.targets;
        int nbTargets = targets.length;
        if (nbTargets > 0) {
            if (firstUpload || i0 != value) {
                for (class_284 target : targets) {
                    target.method_35649(value);
                }
                i0 = value;
                firstUpload = false;
            }
        }
    }

    @Override
    public void set(int value0, int value1) {
        class_284[] targets = this.targets;
        int nbTargets = targets.length;
        if (nbTargets > 0) {
            if (firstUpload || i0 != value0 || i1 != value1) {
                for (class_284 target : targets) {
                    target.method_35650(value0, value1);
                }
                i0 = value0;
                i1 = value1;
                firstUpload = false;
            }
        }
    }

    @Override
    public void set(int value0, int value1, int value2) {
        class_284[] targets = this.targets;
        int nbTargets = targets.length;
        if (nbTargets > 0) {
            if (firstUpload || i0 != value0 || i1 != value1 || i2 != value2) {
                for (class_284 target : targets) {
                    target.method_35651(value0, value1, value2);
                }
                i0 = value0;
                i1 = value1;
                i2 = value2;
                firstUpload = false;
            }
        }
    }

    @Override
    public void set(int value0, int value1, int value2, int value3) {
        class_284[] targets = this.targets;
        int nbTargets = targets.length;
        if (nbTargets > 0) {
            if (firstUpload || i0 != value0 || i1 != value1 || i2 != value2 || i3 != value3) {
                for (class_284 target : targets) {
                    target.method_35656(value0, value1, value2, value3);
                }
                i0 = value0;
                i1 = value1;
                i2 = value2;
                i3 = value3;
                firstUpload = false;
            }
        }
    }

    @Override
    public void set(float value) {
        class_284[] targets = this.targets;
        int nbTargets = targets.length;
        if (nbTargets > 0) {
            if (firstUpload || f0 != value) {
                for (class_284 target : targets) {
                    target.method_1251(value);
                }
                f0 = value;
                firstUpload = false;
            }
        }
    }

    @Override
    public void set(float value0, float value1) {
        class_284[] targets = this.targets;
        int nbTargets = targets.length;
        if (nbTargets > 0) {
            if (firstUpload || f0 != value0 || f1 != value1) {
                for (class_284 target : targets) {
                    target.method_1255(value0, value1);
                }
                f0 = value0;
                f1 = value1;
                firstUpload = false;
            }
        }
    }

    @Override
    public void set(Vector2f value) {
        set(value.x(), value.y());
    }

    @Override
    public void set(float value0, float value1, float value2) {
        class_284[] targets = this.targets;
        int nbTargets = targets.length;
        if (nbTargets > 0) {
            if (firstUpload || f0 != value0 || f1 != value1 || f2 != value2) {
                for (class_284 target : targets) {
                    target.method_1249(value0, value1, value2);
                }
                f0 = value0;
                f1 = value1;
                f2 = value2;
                firstUpload = false;
            }
        }
    }

    @Override
    public void set(Vector3f value) {
        set(value.x(), value.y(), value.z());
    }

    @Override
    public void set(float value0, float value1, float value2, float value3) {
        class_284[] targets = this.targets;
        int nbTargets = targets.length;
        if (nbTargets > 0) {
            if (firstUpload || f0 != value0 || f1 != value1 || f2 != value2 || f3 != value3) {
                for (class_284 target : targets) {
                    target.method_35657(value0, value1, value2, value3);
                }
                f0 = value0;
                f1 = value1;
                f2 = value2;
                f3 = value3;
                firstUpload = false;
            }
        }
    }

    @Override
    public void set(Vector4f value) {
        set(value.x(), value.y(), value.z(), value.w());
    }

    @Override
    public void set(Matrix4f value) {
        class_284[] targets = this.targets;
        int nbTargets = targets.length;
        if (nbTargets > 0) {
            for (class_284 target : targets) {
                target.method_1250(value);
            }
        }
    }

    @Override
    public void setFromArray(float[] values) {
        if (this.count != values.length) {
            throw new IllegalArgumentException("Mismatched values size, expected " + count + " but got " + values.length);
        }

        class_284[] targets = this.targets;
        int nbTargets = targets.length;
        if (nbTargets > 0) {
            for (class_284 target : targets) {
                target.method_1253(values);
            }
        }
    }
}
