/*
 * Satin
 * Copyright (C) 2019-2024 Ladysnake
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; If not, see <https://www.gnu.org/licenses>.
 */
package ladysnake.satin.impl;

import ladysnake.satin.Satin;
import ladysnake.satin.api.managed.ManagedFramebuffer;
import net.minecraft.class_1041;
import net.minecraft.class_1921;
import net.minecraft.class_276;
import net.minecraft.class_279;
import net.minecraft.class_310;
import javax.annotation.Nullable;

public final class FramebufferWrapper implements ManagedFramebuffer {
    private final RenderLayerSupplier renderLayerSupplier;
    private final String name;
    @Nullable
    private class_276 wrapped;

    FramebufferWrapper(String name) {
        this.name = name;
        this.renderLayerSupplier = RenderLayerSupplier.framebuffer(
                this.name + System.identityHashCode(this),
                () -> this.beginWrite(false),
                () -> class_310.method_1551().method_1522().method_1235(false)
        );
    }

    void findTarget(@Nullable class_279 shaderEffect) {
        if (shaderEffect == null) {
            this.wrapped = null;
        } else {
            this.wrapped = shaderEffect.method_1264(this.name);
            if (this.wrapped == null) {
                Satin.LOGGER.warn("No target framebuffer found with name {} in shader {}", this.name, shaderEffect.method_1260());
            }
        }
    }

    public String getName() {
        return name;
    }

    @Nullable
    @Override
    public class_276 getFramebuffer() {
        return wrapped;
    }

    @Override
    public void copyDepthFrom(class_276 buffer) {
        if (this.wrapped != null) {
            this.wrapped.method_29329(buffer);
        }
    }

    @Override
    public void beginWrite(boolean updateViewport) {
        if (this.wrapped != null) {
            this.wrapped.method_1235(updateViewport);
        }
    }

    @Override
    public void draw() {
        class_1041 window = class_310.method_1551().method_22683();
        this.draw(window.method_4489(), window.method_4506(), true);
    }

    @Override
    public void draw(int width, int height, boolean disableBlend) {
        if (this.wrapped != null) {
            this.wrapped.method_22594(width, height, disableBlend);
        }
    }

    @Override
    public void clear() {
        clear(class_310.field_1703);
    }

    @Override
    public void clear(boolean swallowErrors) {
        if (this.wrapped != null) {
            this.wrapped.method_1230(swallowErrors);
        }
    }

    @Override
    public class_1921 getRenderLayer(class_1921 baseLayer) {
        return this.renderLayerSupplier.getRenderLayer(baseLayer);
    }
}
