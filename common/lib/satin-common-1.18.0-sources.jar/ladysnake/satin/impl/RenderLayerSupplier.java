/*
 * Satin
 * Copyright (C) 2019-2024 Ladysnake
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; If not, see <https://www.gnu.org/licenses>.
 */
package ladysnake.satin.impl;

import ladysnake.satin.mixin.client.render.RenderPhaseAccessor;
import net.minecraft.class_1921;
import net.minecraft.class_293;
import net.minecraft.class_4668;
import net.minecraft.class_5944;
import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.Map;
import java.util.function.Consumer;
import java.util.function.Supplier;

public class RenderLayerSupplier {
    private final Consumer<class_1921.class_4688.class_4689> transform;
    private final Map<class_1921, class_1921> renderLayerCache = new HashMap<>();
    private final String uniqueName;
    private final @Nullable class_293 vertexFormat;

    public static RenderLayerSupplier framebuffer(String name, Runnable setupState, Runnable cleanupState) {
        class_4668.class_4678 target = new class_4668.class_4678(
                name + "_target",
                setupState,
                cleanupState
        );
        return new RenderLayerSupplier(name, builder -> builder.method_23610(target));
    }

    public static RenderLayerSupplier shader(String name, class_293 vertexFormat, Supplier<class_5944> shaderSupplier) {
        class_4668 shader = Helper.makeShader(shaderSupplier);
        return new RenderLayerSupplier(name, vertexFormat, builder -> Helper.applyShader(builder, shader));
    }

    public RenderLayerSupplier(String name,  Consumer<class_1921.class_4688.class_4689> transformer) {
        this(name, null, transformer);
    }

    public RenderLayerSupplier(String name, @Nullable class_293 vertexFormat, Consumer<class_1921.class_4688.class_4689> transformer) {
        this.uniqueName = name;
        this.vertexFormat = vertexFormat;
        this.transform = transformer;
    }

    public class_1921 getRenderLayer(class_1921 baseLayer) {
        class_1921 existing = this.renderLayerCache.get(baseLayer);
        if (existing != null) {
            return existing;
        }
        String newName = ((RenderPhaseAccessor) baseLayer).getName() + "_" + this.uniqueName;
        class_1921 newLayer = RenderLayerDuplicator.copy(baseLayer, newName, this.vertexFormat, this.transform);
        this.renderLayerCache.put(baseLayer, newLayer);
        return newLayer;
    }

    /**
     * Big brain move right there
     */
    private static class Helper extends class_4668 {
        public static class_4668 makeShader(Supplier<net.minecraft.class_5944> shader) {
            return new class_5942(shader);
        }

        public static void applyShader(class_1921.class_4688.class_4689 builder, class_4668 shader) {
            builder.method_34578((class_5942) shader);
        }

        private Helper(String name, Runnable beginAction, Runnable endAction) {
            super(name, beginAction, endAction);
        }
    }
}
