/*
 * Satin
 * Copyright (C) 2019-2024 Ladysnake
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; If not, see <https://www.gnu.org/licenses>.
 */
package ladysnake.satin.mixin.client.render;

import net.minecraft.class_1921;
import net.minecraft.class_4668;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1921.class)
public abstract class RenderLayerMixin extends class_4668 {
    public RenderLayerMixin(String name, Runnable beginAction, Runnable endAction) {
        super(name, beginAction, endAction);
    }

    @Mixin(class_1921.class_4688.class)
    public interface MultiPhaseParametersAccessor {
        @Accessor
        class_5939 getTexture();

        @Accessor
        class_5942 getProgram();

        @Accessor
        class_4685 getTransparency();

        @Accessor
        class_4672 getDepthTest();

        @Accessor
        class_4671 getCull();

        @Accessor
        class_4676 getLightmap();

        @Accessor
        class_4679 getOverlay();

        @Accessor
        class_4675 getLayering();

        @Accessor
        class_4678 getTarget();

        @Accessor
        class_4684 getTexturing();

        @Accessor
        class_4686 getWriteMaskState();

        @Accessor
        class_4677 getLineWidth();

        @Accessor
        class_1921.class_4750 getOutlineMode();
    }
}
