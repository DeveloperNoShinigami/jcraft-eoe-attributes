/*
 * Satin
 * Copyright (C) 2019-2024 Ladysnake
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; If not, see <https://www.gnu.org/licenses>.
 */
package ladysnake.satin.mixin.client.event;

import com.llamalad7.mixinextras.sugar.Local;
import ladysnake.satin.api.event.EntitiesPostRenderCallback;
import ladysnake.satin.api.event.EntitiesPreRenderCallback;
import ladysnake.satin.api.event.PostWorldRenderCallbackV2;
import ladysnake.satin.api.event.PostWorldRenderCallbackV3;
import ladysnake.satin.api.experimental.ReadableDepthFramebuffer;
import net.minecraft.class_310;
import net.minecraft.class_4184;
import net.minecraft.class_4587;
import net.minecraft.class_4604;
import net.minecraft.class_757;
import net.minecraft.class_761;
import net.minecraft.class_765;
import org.joml.Matrix4f;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
import org.spongepowered.asm.mixin.injection.Slice;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_761.class)
public abstract class WorldRendererMixin {
    @Unique
    private class_4604 frustum;

    //TODO
    @ModifyVariable(
            method = "render",
            at = @At(value = "CONSTANT", args = "stringValue=entities", ordinal = 0, shift = At.Shift.BEFORE)
    )
    private class_4604 captureFrustum(class_4604 frustum) {
        this.frustum = frustum;
        return frustum;
    }




    @Inject(
            method = "render",
            at = @At(value = "CONSTANT", args = "stringValue=entities", ordinal = 0)
    )
    private void firePreRenderEntities(class_4587 matrix, float tickDelta, long time, boolean renderBlockOutline, class_4184 camera, class_757 renderer, class_765 lmTexManager, Matrix4f matrix4f, CallbackInfo ci) {
        EntitiesPreRenderCallback.EVENT.invoker().beforeEntitiesRender(camera, frustum, tickDelta);
    }

    @Inject(
            method = "render",
            at = @At(value = "CONSTANT", args = "stringValue=blockentities", ordinal = 0)
    )
    private void firePostRenderEntities(class_4587 matrix, float tickDelta, long time, boolean renderBlockOutline, class_4184 camera, class_757 renderer, class_765 lmTexManager, Matrix4f matrix4f, CallbackInfo ci) {
        EntitiesPostRenderCallback.EVENT.invoker().onEntitiesRendered(camera, frustum, tickDelta);
    }

    @Inject(
            method = "render",
            slice = @Slice(from = @At(value = "FIELD:LAST", opcode = Opcodes.GETFIELD, target = "Lnet/minecraft/client/render/WorldRenderer;transparencyPostProcessor:Lnet/minecraft/client/gl/PostEffectProcessor;")),
            at = {
                    @At(value = "INVOKE", target = "Lnet/minecraft/client/gl/PostEffectProcessor;render(F)V"),
                    @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/systems/RenderSystem;depthMask(Z)V", ordinal = 1, shift = At.Shift.AFTER)
            }
    )
    private void hookPostWorldRender(class_4587 matrices, float tickDelta, long nanoTime, boolean renderBlockOutline, class_4184 camera, class_757 renderer, class_765 lmTexManager, Matrix4f matrix4f, CallbackInfo ci) {
        ((ReadableDepthFramebuffer) class_310.method_1551().method_1522()).freezeDepthMap();
        PostWorldRenderCallbackV2.EVENT.invoker().onWorldRendered(matrices, camera, tickDelta, nanoTime);
    }
}
