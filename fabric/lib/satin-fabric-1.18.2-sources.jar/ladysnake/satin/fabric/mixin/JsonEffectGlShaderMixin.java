/*
 * Satin
 * Copyright (C) 2019-2024 Ladysnake
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU Lesser General Public
 * License as published by the Free Software Foundation; either
 * version 3 of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
 * Lesser General Public License for more details.
 *
 * You should have received a copy of the GNU Lesser General Public License
 * along with this program; If not, see <https://www.gnu.org/licenses>.
 */
package ladysnake.satin.fabric.mixin;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Local;
import ladysnake.satin.impl.SamplerAccess;
import net.minecraft.class_280;
import net.minecraft.class_281;
import net.minecraft.class_2960;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import java.util.List;
import java.util.Map;
import java.util.function.IntSupplier;

/**
 * Minecraft does not take into account domains when parsing a shader program.
 * These hooks redirect identifier instantiations to allow specifying a domain for shader files.
 */

@Mixin(class_280.class)
public abstract class JsonEffectGlShaderMixin implements SamplerAccess {
    @Shadow @Final private Map<String, IntSupplier> samplerBinds;

    @Override
    public void satin$removeSampler(String name) {
        this.samplerBinds.remove(name);
    }

    @Override
    public boolean satin$hasSampler(String name) {
        return this.samplerBinds.containsKey(name);
    }

    @Override
    @Accessor("samplerNames")
    public abstract List<String> satin$getSamplerNames();

    @Override
    @Accessor("samplerLocations")
    public abstract List<Integer> satin$getSamplerShaderLocs();

    /**
     * Fix identifier creation to allow different namespaces
     */
    @WrapOperation(
            at = @At(
                    value = "NEW",
                    target = "net/minecraft/util/Identifier",
                    ordinal = 0
            ),
            method = "<init>"
    )
    class_2960 constructProgramIdentifier(String arg, Operation<class_2960> original, @Local(argsOnly = true) String id) {
        if (!id.contains(":")) {
            return original.call(arg);
        }
        class_2960 split = new class_2960(id);
        return new class_2960(split.method_12836(), "shaders/program/" + split.method_12832() + ".json");
    }

    @WrapOperation(
            at = @At(
                    value = "NEW",
                    target = "net/minecraft/util/Identifier",
                    ordinal = 0
            ),
            method = "loadEffect"
    )
    private static class_2960 constructProgramIdentifier(String arg, Operation<class_2960> original, @Local(argsOnly = true) class_281.class_282 shaderType,  @Local(argsOnly = true) String id) {
        if (!arg.contains(":")) {
            return original.call(arg);
        }
        class_2960 split = new class_2960(id);
        return new class_2960(split.method_12836(), "shaders/program/" + split.method_12832() + shaderType.method_1284());
    }
}