package ladysnake.satin.platform.fabric;

import net.fabricmc.fabric.impl.client.rendering.FabricShaderProgram;
import net.minecraft.class_293;
import net.minecraft.class_2960;
import net.minecraft.class_5912;
import net.minecraft.class_5944;
import java.io.IOException;

public class PlatformUtilImpl {

    public static class_5944 getShaderProgramClass(class_5912 resourceManager, class_2960 location, class_293 vertexFormat) throws IOException {
        return new FabricShaderProgram(resourceManager, location, vertexFormat);
    }
}
